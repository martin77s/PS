﻿  xPackage DotNetFramework452
    {
        Ensure = 'Present'
        Name = ''
        Path  = '\\ServerName\Share\.Net 4.5.2\NDP452-KB2901907-x86-x64-AllOS-ENU.exe'
        ProductId = ''
        Arguments = '/q /norestart'
        ReturnCode = @(0,3010)
        InstalledCheckRegKey = 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
        InstalledCheckRegValueName = 'Release'
        InstalledCheckRegValueData = '379893'
    }
