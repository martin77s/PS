﻿'DSCEA'
'CertificateDsc',
'PSDscResources',
'ComputerManagementDsc',
'WebAdministrationDsc',
'xPSDesiredStateConfiguration',
'xDSCResourceDesigner',
'xDscDiagnostics',
'xPendingReboot' | % { Find-Module -Name $_ | Save-Module -Path C:\Temp\MoE -Verbose }