﻿function Decrypt-MOF {
    param($Path = "$env:SystemRoot\system32\configuration\current.mof")

    [system.text.encoding]::Unicode.GetString(
      [System.Security.Cryptography.ProtectedData]::Unprotect(
        [system.Text.Encoding]::Default.GetBytes(
            (Get-Content -Path $Path -Raw)), $null, 
                [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
    )
}