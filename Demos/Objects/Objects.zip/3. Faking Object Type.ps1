break

$proc = [PSCustomObject]@{
    ProcessName = 'nimda.exe'
    ID          = -1
    PSTypeName  = 'System.Diagnostics.Process'
}

$proc